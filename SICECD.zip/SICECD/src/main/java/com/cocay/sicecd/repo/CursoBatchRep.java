package com.cocay.sicecd.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cocay.sicecd.model.Curso;

public interface CursoBatchRep extends JpaRepository<Curso, Integer>{

}
