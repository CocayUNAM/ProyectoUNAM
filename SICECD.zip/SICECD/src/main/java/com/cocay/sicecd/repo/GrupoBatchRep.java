package com.cocay.sicecd.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cocay.sicecd.model.Grupo;

public interface GrupoBatchRep extends JpaRepository<Grupo, Integer>{

}