package com.cocay.sicecd.dto;

public class CursoDto {
	
	String clave;
	
	String tipo;
	
	String horas;
	
	String nombre;
	
	String fInicio;
	
	String fTermino;

	public String getClave() {
		return clave;
	}

	public void setClave(String clave) {
		this.clave = clave;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getHoras() {
		return horas;
	}

	public void setHoras(String horas) {
		this.horas = horas;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getfInicio() {
		return fInicio;
	}

	public void setfInicio(String fInicio) {
		this.fInicio = fInicio;
	}

	public String getfTermino() {
		return fTermino;
	}

	public void setfTermino(String fTermino) {
		this.fTermino = fTermino;
	}
}
