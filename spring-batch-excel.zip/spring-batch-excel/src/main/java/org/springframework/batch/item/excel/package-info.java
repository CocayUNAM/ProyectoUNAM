/**
 * Core interfaces for reading Excel files
 */
package org.springframework.batch.item.excel;