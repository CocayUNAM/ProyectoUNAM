/**
 * Support classes for the JExcel library.
 */
package org.springframework.batch.item.excel.jxl;