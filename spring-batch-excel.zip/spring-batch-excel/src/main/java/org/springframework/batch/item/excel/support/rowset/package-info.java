/**
 * RowSet abstraction for Excel documents
 */
package org.springframework.batch.item.excel.support.rowset;