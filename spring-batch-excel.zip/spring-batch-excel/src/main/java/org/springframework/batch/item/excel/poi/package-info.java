/**
 * Support classes for the Apache POI library.
 */
package org.springframework.batch.item.excel.poi;